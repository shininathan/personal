<!DOCTYPE html>
<html>
	<title>Datatable Demo9   DataTable Search By Datepicker | CoderExample</title>
	<head>
	
		<link rel="stylesheet" type="text/css" href="css/jquery.dataTables.css">
		<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
		<script type="text/javascript" language="javascript" src="js/jquery.js"></script>
		<script type="text/javascript" language="javascript" src="js/jquery.dataTables.js"></script>
		 <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
		<script type="text/javascript" language="javascript" >
			$(document).ready(function() {
			
				var dataTable =  $('#user').DataTable( {
				processing: true,
				serverSide: true,
				ajax: "udata.php", // json datasource

				} );
				
				$("#udata_filter").css("display","none");  // hiding global search box
				
				$('.sinput').on( 'keyup click change', function () {   
					var i =$(this).attr('id');  // getting column index
					var v =$(this).val();  // getting search input value
					dataTable.columns(i).search(v).draw();
				} );
		
				 $( ".datepicker" ).datepicker({
				 	dateFormat: "yy-mm-dd",
					showOn: "button",
					showAnim: 'slideDown',
					showButtonPanel: true ,
					autoSize: true,
					buttonImage: "//jqueryui.com/resources/demos/datepicker/images/calendar.gif",
					buttonImageOnly: true,
					buttonText: "Select date",
					closeText: "Clear"
				});
				$(document).on("click", ".ui-datepicker-close", function(){
					$('.datepicker').val("");
					dataTable.columns(8).search("").draw();
				});
			} );

		</script>
		<style>
			
			body {
			    background: #f7f7f7;
			    color: #333;
			}
			.sinput {
			    width: 100%;
			}
			.datepicker {
				float:left;width:70%;
			}
		</style>
		
	</head>
	<body>
		<div class="header"><h1>DataTable Search By Datepicker</h1></div>
		<div class="container">
			<table id="user"  class="display" cellspacing="0" width="100%">
				<thead>
					<tr>
<th>id</th>
<th>name</th>
<th>eid</th>
<th>title</th>
<th>id</th>
<th>name</th>
<th>eid</th>
<th>title</th>
<th>id</th>
<th>name</th>

					</tr>
				</thead>
				<thead>
					<tr>
						<td><input type="text" id="0"  class="sinput"></td>
						<td><input type="text" id="1" class="sinput"></td>
	<td><input type="text" id="2" class="sinput"></td>
		<td><input type="text" id="3" class="sinput"></td>	
			<td><input type="text" id="4"  class="sinput"></td>
						<td><input type="text" id="5" class="sinput"></td>
	<td><input type="text" id="6" class="sinput"></td>
		<td><input type="text" id="7" class="sinput"></td>	
			<td  valign="middle"><input  readonly="readonly" type="text" id="8" class="employee-search-input datepicker" ></td>
						<td><input type="text" id="9" class="sinput"></td>
	
					</tr>
				</thead>
			</table>
		</div>
	</body>
</html>
