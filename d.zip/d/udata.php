<?php
/* Database connection start */
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "quiz";

$conn = mysqli_connect($servername, $username, $password, $dbname) or die("Connection failed: " . mysqli_connect_error());

/* Database connection end */


// storing  request (ie, get/post) global array to a variable  
$requestData= $_REQUEST;




$columns = array( 
// datatable column index  => database column name
0 => "user.id", 
1 => "user.name",
2 => "user.branch",
3 => "history.score",
4 => "history.level", 
5 => "history.correct",
6 => "history.wrong",
7 => "history.status",
8 => "history.date", 
9 => "quiz.title"
);



// getting total number records without any search
$sql = " SELECT * FROM  user 
 INNER JOIN history on user.username=history.username
 INNER JOIN quiz on history.eid=quiz.eid";
$query=mysqli_query($conn, $sql) or die("udata.php: get user");
$totalData = mysqli_num_rows($query);
$totalFiltered = $totalData;  // when there is no search parameter then total number rows = total number filtered rows.


$sql = "SELECT user.id, user.name, user.branch, history.score,history.level,history.correct, history.wrong,history.status, DATE_FORMAT(history.date, '%Y-%m-%d') as date, quiz.title ";
$sql.=" FROM user inner join history on user.username=history.username
INNER JOIN quiz on history.eid=quiz.eid
 WHERE 1=1";
if( !empty($requestData['columns'][0]['search']['value']) ){
	$sql.=" AND  user.id LIKE '".$requestData['columns'][0]['search']['value']."%' ";    
}
if( !empty($requestData['columns'][1]['search']['value']) ){
	$sql.=" AND  user.name LIKE '".$requestData['columns'][1]['search']['value']."%' ";
}
if( !empty($requestData['columns'][2]['search']['value']) ){
	$sql.=" AND  user.branch LIKE '".$requestData['columns'][2]['search']['value']."%' ";
}
if( !empty($requestData['columns'][3]['search']['value']) ){
	$sql.=" AND  history.score LIKE '".$requestData['columns'][3]['search']['value']."%' ";
}
if( !empty($requestData['columns'][4]['search']['value']) ){
	$sql.=" AND  history.level LIKE '".$requestData['columns'][4]['search']['value']."%' ";    
}
if( !empty($requestData['columns'][5]['search']['value']) ){
	$sql.=" AND  history.correct LIKE '".$requestData['columns'][5]['search']['value']."%' ";
}
if( !empty($requestData['columns'][6]['search']['value']) ){
	$sql.=" AND  history.wrong LIKE '".$requestData['columns'][6]['search']['value']."%' ";
}
if( !empty($requestData['columns'][7]['search']['value']) ){
	$sql.=" AND  history.status LIKE '".$requestData['columns'][7]['search']['value']."%' ";
}
if( !empty($requestData['columns'][8]['search']['value']) ){
	$sql.=" AND  history.date LIKE '".$requestData['columns'][8]['search']['value']."%' ";    
}
if( !empty($requestData['columns'][9]['search']['value']) ){
	$sql.=" AND  quiz.title LIKE '".$requestData['columns'][9]['search']['value']."%' ";
}


$query=mysqli_query($conn, $sql) or die("udata.php: get user");
$totalFiltered = mysqli_num_rows($query); // when there is a search parameter then we have to modify total number filtered rows as per search result. 
$sql.=" ORDER BY ". $columns[$requestData['order'][0]['column']]."   ".$requestData['order'][0]['dir']."  LIMIT ".$requestData['start']." ,".$requestData['length']."   ";
/* $requestData['order'][0]['column'] contains column index, $requestData['order'][0]['dir'] contains order such as asc/desc  */	
$query=mysqli_query($conn, $sql) or die("udata.php: get user1");
	

$data = array();
while( $row=mysqli_fetch_array($query) ) {  // preparing an array
	$nestedData=array(); 

$nestedData[] = $row["id"];
$nestedData[] = $row["name"];
$nestedData[] = $row["branch"];
$nestedData[] = $row["score"];
$nestedData[] = $row["level"];
$nestedData[] = $row["correct"];
$nestedData[] = $row["wrong"];
$nestedData[] = $row["status"];
$nestedData[] = $row["date"];
$nestedData[] = $row["title"];
	
	$data[] = $nestedData;
}

$json_data = array(
			"draw"            => intval( $requestData['draw'] ),   // for every request/draw by clientside , they send a number as a parameter, when they recieve a response/data they first check the draw number, so we are sending same number in draw. 
			"recordsTotal"    => intval( $totalData ),  // total number of records
			"recordsFiltered" => intval( $totalFiltered ), // total number of records after searching, if there is no searching then totalFiltered = totalData
			"data"            => $data   // total data array
			);

echo json_encode($json_data);  // send data as json format

?>
